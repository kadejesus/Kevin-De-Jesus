counter = 0
answer = 'y'
overallaverage = 0
finalaverage = 0 
while answer == 'y' or answer == 'Y':
  total = 0
  highest = 0
  lowest = 10
  for i in range(5):
    score = float(input("What is your score?"))
    while score < 0 or score > 10:
      print 'Invalid score! Try again.'
      score = float(input("What is your score?"))
    if score > highest:
      highest = score
    if score < lowest:
      lowest = score
      total += score
  print highest, lowest
  #calculate the average
  average = (total - highest - lowest)/3
  print 'Average: ', average
  counter = counter + 1
  anwer = input("Do you have another entry?")
finalaverage = overallaverage/counter
print ' There were ', counter, 'entries.'